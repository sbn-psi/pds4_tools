__author__ = "Lev Nagdimunov"
__copyright__ = "2015 - 2025, University of Maryland"

__version__ = "1.5.dev0"
__email__ = "lnagdi1@astro.umd.edu"
