pds4_tools.reader.read_tables module
====================================

.. currentmodule:: pds4_tools.reader.read_tables

Functions
---------

.. autosummary::

    read_table
    read_table_data
    new_table
    table_data_size_check

Details
-------

.. autofunction:: read_table
.. autofunction:: read_table_data
.. autofunction:: new_table
.. autofunction:: table_data_size_check
