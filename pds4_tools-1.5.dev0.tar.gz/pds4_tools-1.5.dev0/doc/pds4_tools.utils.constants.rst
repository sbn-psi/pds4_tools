pds4_tools.utils.constants module
=================================

.. automodule:: pds4_tools.utils.constants

.. autoattribute:: pds4_tools.utils.constants.PDS4_NAMESPACES

.. autoattribute:: pds4_tools.utils.constants.PDS4_DATA_ROOT_ELEMENTS

.. autoattribute:: pds4_tools.utils.constants.PDS4_DATA_FILE_AREAS
